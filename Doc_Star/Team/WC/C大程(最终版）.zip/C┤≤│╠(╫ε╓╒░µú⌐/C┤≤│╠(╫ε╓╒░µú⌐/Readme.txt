ManualEdit : 交互式编辑地图，起点终点已给出   左键单击生成障碍 右键单击消除
CreatPlayer: 生成玩家初始坐标
CreatEnd : 生成终点坐标
PrintPlayer:  画出玩家
PrintEnd:     画出终点
CreatMap：       生成随机地图
DrawMap:      画出随机地图
 