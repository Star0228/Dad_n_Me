#pragma once

#include <conio.h>
#include <windows.h>
#include <wincon.h>
#include <Windows.h>

HBITMAP readBmpImage(char *fileName);
